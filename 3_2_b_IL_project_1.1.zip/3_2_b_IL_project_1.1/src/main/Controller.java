package main;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToolBar;

public class Controller extends JFrame implements Listener {

	Container mp = Container.getInstance();

	public Controller() {
		Container.addListener(this);
		Container.resetGame();
		this.setTitle("Rodents revenge");
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setLocationByPlatform(true);
		panelChanged();
		// ensures the frame is the minimum size it needs to be
		// in order display the components within it
		this.pack();
		// ensures the minimum size is enforced.
		this.setMinimumSize(this.getSize());
		this.setVisible(true);
	}

	private final JLabel message = new JLabel("w,s,a,d for Rat and i,k,j,l for Cat!");

	@Override
	public void panelChanged() {

		JPanel contentPane = (JPanel) this.getContentPane();
		contentPane.removeAll();
		JToolBar tools = new JToolBar();

		this.add(mp.getGui());
		tools.setFloatable(false);
		this.add(tools, BorderLayout.PAGE_START);
		tools.add(new JButton(new AbstractAction("New") {
			public void actionPerformed(ActionEvent e) {
				Container.resetGame();
			}
		}));
		tools.addSeparator();
		tools.add(new JButton(new AbstractAction("Exit") {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		}));
		tools.addSeparator();
		tools.add(message);
		this.revalidate();
		this.repaint();
	}

}
