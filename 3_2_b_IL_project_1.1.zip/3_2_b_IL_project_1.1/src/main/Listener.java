package main;

public interface Listener {
void panelChanged();
}
