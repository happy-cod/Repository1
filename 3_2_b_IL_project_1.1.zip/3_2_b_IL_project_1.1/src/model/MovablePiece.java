package model;

public abstract class MovablePiece extends Piece {
	private int id;
	protected Board board;

	public MovablePiece(Board board, int id) {
		this.board = board;
		this.id = id;
	}

	public abstract void moveTo(Direction dir);

	public abstract void visit(Rat rat, Direction fromDir);

	public abstract void visit(Cat cat, Direction fromDir);

	public abstract void visit(MovableBlock movBlock, Direction fromDir);

	public abstract void visit(ImmovableBlock immoBlock, Direction fromDir);

	public abstract void visit(EmptyPiece empty, Direction fromDir);

	public abstract void visit(Cheese cheese, Direction fromDir);

	public int getId() {
		return id;
	}
}
