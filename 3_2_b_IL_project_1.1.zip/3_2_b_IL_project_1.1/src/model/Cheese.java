package model;

import view.CheeseView;


public class Cheese extends Piece {

	public Cheese() {
		this.view = new CheeseView();
	}
	
	@Override
	public void accept(MovablePiece p, Direction fromDir) {		
		p.visit(this, fromDir);
	}

	@Override
	public String getSymbol() {
		return "F";
	}
}
