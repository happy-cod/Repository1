package model;

import java.util.ArrayList;

import main.Container;


public class Initializer {
	private Board board;
	private ArrayList<RatController> ratControllers = new ArrayList<>();
	private ArrayList<CatController> catControllers = new ArrayList<>();

	public Initializer() {
	}

	public void initBoard(int rows, int cols) {
		board = new Board(rows, cols);
		board.getRules().setInitializer(this);
	}

	public Board getBoard() {
		return board;
	}

	public void addPiece(Byte pieceSymbol, Position pos) {
		switch (pieceSymbol) {
		case 'R':
			RatController rc = new RatController(board, ratControllers.size() + 1);
			ratControllers.add(rc);
			board.putPieceAt(rc.getPiece(), pos);
			break;
		case 'C':
			CatController cc = new CatController(board, catControllers.size() + 1);
			catControllers.add(cc);
			board.putPieceAt(cc.getPiece(), pos);
			break;
		case 'M':
			board.putPieceAt(new MovableBlock(board, 0), pos);
			break;
		case 'I':
			board.putPieceAt(new ImmovableBlock(), pos);
			break;
		case 'E':
			board.putPieceAt(new EmptyPiece(), pos);
			break;
		case 'F':
			board.putPieceAt(new Cheese(), pos);
			break;
		default:
			return;
		}
	}

	public void moveRat(int id, Direction dir) {
		ratControllers.get(id - 1).moveRat(dir);
	}

	public void moveCat(int id, Direction dir) {
		catControllers.get(id - 1).moveCat(dir);
	}

	public void gameOver() {
		Container.resetGame();
	}

}
