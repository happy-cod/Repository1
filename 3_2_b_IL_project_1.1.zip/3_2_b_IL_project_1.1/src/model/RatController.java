package model;


public class RatController {
	
	private Rat rat;
	
	public RatController(Board board, int id) {
		this.rat = new Rat(board, id);
	}

	
	public Rat getPiece() {
		return this.rat;
	}
	
	
	public void moveRat(Direction dir) {
		rat.moveTo(dir);
	}
	
}
