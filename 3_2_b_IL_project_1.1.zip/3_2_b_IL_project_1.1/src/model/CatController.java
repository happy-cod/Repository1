package model;


public class CatController {
	private Cat cat;
	
	public CatController(Board board, int id) {
		this.cat = new Cat(board, id);
	}

	public Cat getPiece() {
		return this.cat;
	}
	
	public void moveCat(Direction dir) {
		cat.moveTo(dir);
	}
	
}
