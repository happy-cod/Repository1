package model;

public class Rules {
	private Board board;
	private Initializer init;

	public Rules(Board board) {
		this.board = board;
	}

	public void setInitializer(Initializer init) {
		this.init = init;
	}

	private void eat(Piece eater, Piece eaten) {
		EmptyPiece newEmpty = new EmptyPiece();
		newEmpty.setPosition(eaten.getPosition());

		board.switchPieces(eater, newEmpty);
	}

	private void moveIfPossible(MovablePiece fromPiece, MovablePiece toPiece, Direction dir) {
		toPiece.moveTo(dir);
		Piece adjacentPiece = this.board.getAdjacentPiece(fromPiece.getPosition(), dir);
		if (adjacentPiece != toPiece) {
			board.switchPieces(fromPiece, adjacentPiece);
		}
	}

	private void playerLosesLife() {
		init.gameOver();
	}

	public void resolve(Cat fromCat, Rat toRat) {
		playerLosesLife();
		init.gameOver();

	}

	public void resolve(Cat fromCat, Cat toCat) {
	}

	public void resolve(Cat fromCat, MovableBlock toMovBlock) {
		// Do nothing
	}

	public void resolve(Cat fromCat, ImmovableBlock toImmoBlock) {
	}

	public void resolve(Cat fromCat, EmptyPiece toEmpty) {
		// cat moves
		board.switchPieces(fromCat, toEmpty);
	}

	public void resolve(Cat fromCat, Cheese toCheese) {
		// the cat eats the cheese
		this.eat(fromCat, toCheese);
	}

	public void resolve(Rat fromRat, Rat toRat) {
		// Do nothing
	}

	public void resolve(Rat fromRat, Cat toCat) {
		playerLosesLife();
		init.gameOver();
	}

	public void resolve(Rat fromRat, MovableBlock toMovBlock, Direction dir) {
		// move the blocks if possible
		this.moveIfPossible(fromRat, toMovBlock, dir);
	}

	public void resolve(Rat fromRat, ImmovableBlock toImmoBlock) {
	}

	public void resolve(Rat fromRat, EmptyPiece toEmpty) {
		// the rat moves
		board.switchPieces(fromRat, toEmpty);
	}

	public void resolve(Rat fromRat, Cheese toCheese) {
		this.eat(fromRat, toCheese);
	}

	public void resolve(MovableBlock fromMovBlock, Rat toRat) {
	}

	public void resolve(MovableBlock fromMovBlock, Cat toCat) {
	}

	public void resolve(MovableBlock fromMovBlock, MovableBlock toMovBlock, Direction dir) {
		this.moveIfPossible(fromMovBlock, toMovBlock, dir);
	}

	public void resolve(MovableBlock fromMovBlock, ImmovableBlock toImmoBlock) {
	}

	public void resolve(MovableBlock fromMovBlock, EmptyPiece toEmpty) {
		// the movable block is moved
		board.switchPieces(fromMovBlock, toEmpty);
	}

	public void resolve(MovableBlock fromMovBlock, Cheese toCheese) {
		this.eat(fromMovBlock, toCheese);
	}
}