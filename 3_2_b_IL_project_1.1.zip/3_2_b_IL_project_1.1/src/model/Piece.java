package model;

public abstract class Piece {

	private Position pos;
	protected view.View view;

	public Position getPosition() {
		return pos;
	}

	public void setPosition(Position pos) {
		this.pos = pos;
	}

	public view.View getView() {
		return view;
	}

	public abstract void accept(MovablePiece p, Direction fromDir);

	public abstract String getSymbol();
}
