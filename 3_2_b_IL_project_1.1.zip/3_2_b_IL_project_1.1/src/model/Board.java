package model;

import java.util.ArrayList;

import main.RodentsPanel;
import view.BoardView;

public class Board {
	private view.BoardView boardView;
	private int rows;
	private int cols;

	private Piece[][] cells;
	private Rules rules;

	private ArrayList<Cat> cats;
	private ArrayList<EmptyPiece> emptyPieces;

	public Board(int rows, int cols) {
		boardView = new BoardView();
		this.rows = rows;
		this.cols = cols;
		this.cells = new Piece[rows][cols];
		this.rules = new Rules(this);

		this.cats = new ArrayList<Cat>();
		this.emptyPieces = new ArrayList<EmptyPiece>();
	}

	public RodentsPanel getDraw() {
		return BoardView.draw(cells, rows, cols);
	}

	public Rules getRules() {
		return this.rules;
	}

	public void putPieceAt(Piece piece, Position pos) {
		// Checking to see if the previous Piece at this position was an Empty
		// Piece
		Piece previousPiece = this.cells[pos.getRow()][pos.getColumn()];
		if (previousPiece != null) {
			if (previousPiece.getClass() == EmptyPiece.class) {
				emptyPieces.remove(previousPiece);
			}
			if (previousPiece.getClass() == Cat.class) {
				cats.remove(previousPiece);
			}
		}

		// Adding the input Piece to the emptyPieces list if it is an EmptyPiece
		if (piece.getClass() == EmptyPiece.class) {
			emptyPieces.add((EmptyPiece) piece);
		}

		// Adding the input Piece to the cats list if it is a Cat
		if (piece.getClass() == Cat.class) {
			cats.add((Cat) piece);
		}

		this.cells[pos.getRow()][pos.getColumn()] = piece;
		piece.setPosition(pos);
	}

	public Piece getAdjacentPiece(Position pos, Direction dir) {
		int dir_row = 0, dir_col = 0;
		switch (dir) {
		case UP:
			dir_row = 1;
			break;
		case DOWN:
			dir_row = -1;
			break;
		case LEFT:
			dir_col = -1;
			break;
		case RIGHT:
			dir_col = 1;
			break;
		}
		int adjacentCellRow = pos.getRow() + dir_row;
		int adjacentCellColumn = pos.getColumn() + dir_col;

		if (adjacentCellRow >= 0 && adjacentCellColumn >= 0 && adjacentCellRow < rows && adjacentCellColumn < cols) {
			return cells[adjacentCellRow][adjacentCellColumn];
		}
		return new ImmovableBlock();
	}

	public void switchPieces(Piece p1, Piece p2) {
		Position pos1 = p1.getPosition();
		Position pos2 = p2.getPosition();

		this.putPieceAt(p1, pos2);
		this.putPieceAt(p2, pos1);
	}

	public boolean haveEmptyPiece() {
		return (emptyPieces.size() > 0);
	}
}
