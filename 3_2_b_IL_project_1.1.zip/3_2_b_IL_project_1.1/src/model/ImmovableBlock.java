package model;


public class ImmovableBlock extends Piece {

	public ImmovableBlock() {
		this.view = new view.ImmovableBlockView();
	}
	
	@Override
	public void accept(MovablePiece p, Direction fromDir) {
		p.visit(this, fromDir);
	}
	
	@Override
	public String getSymbol() {
		return "I";
	}
}
