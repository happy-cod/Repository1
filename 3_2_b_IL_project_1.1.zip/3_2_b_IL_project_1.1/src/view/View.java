package view;

import javax.swing.ImageIcon;

public interface View {
public ImageIcon draw();
}
