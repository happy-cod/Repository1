package view;

import javax.swing.ImageIcon;

public class MovableBlockView implements View {

	
	public ImageIcon draw() {
		return new ImageIcon("src\\img\\wall.png");
	}

}
