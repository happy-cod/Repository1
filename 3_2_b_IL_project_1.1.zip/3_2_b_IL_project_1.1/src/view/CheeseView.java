package view;

import javax.swing.ImageIcon;

public class CheeseView implements View {

	
	public ImageIcon draw() {
		return new ImageIcon("src\\img\\cheese.png");
	}

}
