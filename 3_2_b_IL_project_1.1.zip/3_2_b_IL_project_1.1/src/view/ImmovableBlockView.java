package view;

import javax.swing.ImageIcon;

public class ImmovableBlockView implements View {

	
	public ImageIcon draw() {
		return new ImageIcon("src\\img\\block.png");
	}

}
